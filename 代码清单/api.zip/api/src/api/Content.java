package api;

public class Content {
	private Double weight;
	private String word;
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public Content(double d, String word) {
		super();
		this.weight = d;
		this.word = word;
	}

	
}
