package api;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import java.io.PrintWriter;
import java.net.URLConnection;
public class twitter_API {
	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		 return  sb.toString();
	}

    public static JSONObject postRequestFromUrl(String url, String body) throws IOException, JSONException {
        URL realUrl = new URL(url);
        URLConnection conn = realUrl.openConnection();
        conn.setDoOutput(true);
        conn.setDoInput(true);
        PrintWriter out = new PrintWriter(conn.getOutputStream());
        out.print(body);
        out.flush();

        InputStream instream = conn.getInputStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(instream, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json=JSONObject.fromObject(jsonText);
            return json;
		} finally {
        instream.close();
        }
    }

    public static JSONObject getRequestFromUrl(String url) throws IOException, JSONException {
        URL realUrl = new URL(url);
        URLConnection conn = realUrl.openConnection();
        InputStream instream = conn.getInputStream();
        try {
        BufferedReader rd = new BufferedReader(new InputStreamReader(instream, Charset.forName("UTF-8")));
        String jsonText = readAll(rd);
        JSONObject json=JSONObject.fromObject(jsonText);
        return json;
		} finally {
        instream.close();
        }
    }
	public static void main(String[] args) throws IOException, JSONException, InterruptedException {


		for(int k=1;k<=3;k++) {
			String url = "http://120.76.205.241:8000/post/weibo?pageToken="+k+"&uid=2132753977&apikey=ZKZOSU8u70IfS65NR4TFUrKSbPQTfJJO3LgJaQRV4Z8kmLETYBt2KIIfWSZwUKSS";
	        JSONObject json = getRequestFromUrl(url);
	        List<twit> twitters= new ArrayList<twit>();
	        
	        if(json.has("data")) {
	        	System.out.println(json.toString());
	        	JSONArray array = null;
	        	array = json.getJSONArray("data");
	        	
	        	for (int i = 0; i < array.size(); i++) {
	        		JSONObject jo = array.getJSONObject(i);
	        		twitters.add(new twit(jo.getString("content")));
	        	}
	        	for(int i = 0 ; i < twitters.size() ; i++) {
	        		System.out.println(twitters.get(i).getText());
	        	}

	        }
	        try {  
                Thread.sleep(1000);  
            } catch (InterruptedException e) {  
                //�߳��ж��ڴ˴���  
            }  
		}
	}
}
