package api;

public class get_uid {

}
