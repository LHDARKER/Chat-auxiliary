//package com.g11;
//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.widget.TextView;
//
//import org.w3c.dom.Text;
//
//import static com.g11.LoginActivity.loginACache;
//
//public class UserActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_user);
//
//        initViews();
//
//    }
//
//    private void initViews() {
//        TextView text_user_username = findViewById(R.id.text_user_username);
//        text_user_username.setText(loginACache.getAsString("username") + "sbq sb");
//    }
//}
