package com.g11;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.g11.Adapter.TitleAdapter;
import com.g11.Bean.Personal_info;
import com.g11.Utils.RoundImageView;


import org.w3c.dom.Text;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import static com.g11.Utils.Infomation.get;


public class Info_ResultActivity extends AppCompatActivity{
    private String uid;
    private Personal_info info;
    private int theme = R.style.AppTheme;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personal_info);

        initViews();

    }

    private void initViews() {
        uid = getIntent().getStringExtra("uid");
        try {
            info = get(uid);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),  "访问太过频繁",   Toast.LENGTH_SHORT).show();
        }
        RoundImageView viw_avatarUrl = (RoundImageView)findViewById(R.id.viw_avatarUrl);
        URL url = null;
        try {
            url = new URL(info.getAvatarUrl());
            viw_avatarUrl.setImageBitmap(BitmapFactory.decodeStream(url.openStream()));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
//从网上取图片
        TextView viw_name = (TextView)findViewById(R.id.viw_name);
        viw_name.setText(info.getUserName());
        TextView viw_biography = (TextView)findViewById(R.id.viw_biography);
        viw_biography.setText(info.getBiography());
        TextView viw_education = (TextView)findViewById(R.id.viw_education);
        viw_education.setText(info.getEducations());
        TextView viw_work = (TextView)findViewById(R.id.viw_work);
        viw_work.setText(info.getWorks());
        TextView viw_registertime = (TextView)findViewById(R.id.viw_registertime);
        viw_registertime.setText(info.getRegisterDate());
        TextView viw_location = (TextView)findViewById(R.id.viw_location);
        viw_location.setText(info.getLocation());
        TextView viw_birthday = (TextView)findViewById(R.id.viw_birthday);
        viw_birthday.setText(info.getBirthday());
        TextView viw_gender = (TextView)findViewById(R.id.viw_gender);
        viw_gender.setText(info.getGender());
        TextView viw_usertype = (TextView)findViewById(R.id.viw_usertype);
        viw_usertype.setText(info.getIdType());
    }




//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        Intent intent = new Intent();
//
//        intent.putExtra("title", titleList.get(position).getTitle());
//        intent.putExtra("date", titleList.get(position).getPubDate());
//        intent.putExtra("author_name", titleList.get(position).getChannelName());
//        intent.putExtra("url", titleList.get(position).getLink());
//        intent.putExtra("thumbnail_pic_s", titleList.get(position).getImageurl());
//        intent.putExtra( "ShoucangNum",titleList.get( position ).getShoucanNum() );
//        intent.putExtra( "ShoucanFocus",titleList.get( position ).isShoucanFocus() );
//        intent.setClass(this, DetailActivity.class);
//        startActivity(intent);
//    }
}
