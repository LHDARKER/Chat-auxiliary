package com.g11;

import android.app.ActionBar;
import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.suke.widget.SwitchButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public static int theme = R.style.AppTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState != null){
            theme = savedInstanceState.getInt("theme");
            setTheme(theme);
        }
        setContentView(R.layout.activity_main);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        initViews();
    }

    private void initViews() {
        Button bt_news = findViewById(R.id.bt_news);
        bt_news.setOnClickListener(this);
        Button bt_search = findViewById(R.id.bt_search);
        bt_search.setOnClickListener(this);
        Button bt_spider = findViewById(R.id.bt_spider);
        bt_spider.setOnClickListener(this);
        Button bt_user = findViewById(R.id.bt_user);
        bt_user.setOnClickListener(this);

        final com.suke.widget.SwitchButton switchButton = (com.suke.widget.SwitchButton) findViewById(R.id.switch_button);

        switchButton.setChecked(theme == R.style.NightAppTheme);
        switchButton.isChecked();
        switchButton.toggle();     //switch state
        switchButton.toggle(true);//switch without animation
        switchButton.setShadowEffect(true);
        switchButton.setEnabled(true);
        switchButton.setEnableEffect(true);
        switchButton.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                theme = (theme == R.style.AppTheme) ? R.style.NightAppTheme : R.style.AppTheme;
                MainActivity.this.recreate();

//                NewsActivity.class.recreate();//TODO do your job
            }
        });


        LinearLayout main_news = findViewById(R.id.main_news);
        main_news.setOnClickListener(this);
        LinearLayout main_search = findViewById(R.id.main_search);
        main_search.setOnClickListener(this);
        LinearLayout main_spider = findViewById(R.id.main_spider);
        main_spider.setOnClickListener(this);
        LinearLayout main_user = findViewById(R.id.main_user);
        main_user.setOnClickListener(this);
//        TextView main_long = findViewById(R.id.main_long);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_news:
                startActivity(new Intent(MainActivity.this, NewsActivity.class));
                break;
            case R.id.bt_search:
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
                break;
            case R.id.bt_spider:
                startActivity(new Intent(MainActivity.this, SpiderActivity.class));
                break;
            case R.id.bt_user:
                startActivity(new Intent(MainActivity.this, CollectionActivity.class));
                break;

            case R.id.main_news:
                startActivity(new Intent(MainActivity.this, NewsActivity.class));
                break;
            case R.id.main_search:
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
                break;
            case R.id.main_spider:
                startActivity(new Intent(MainActivity.this, SpiderActivity.class));
                break;
            case R.id.main_user:
                startActivity(new Intent(MainActivity.this, CollectionActivity.class));
                break;
            default:
                break;

        }
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

}
