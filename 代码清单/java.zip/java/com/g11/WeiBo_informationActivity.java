package com.g11;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.g11.Adapter.TwitterAdapter;
import com.g11.Bean.twit;

import static com.g11.Utils.twitter_API.get;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class WeiBo_informationActivity extends AppCompatActivity {
    protected List<twit> titleList = new ArrayList<>();
    protected ListView listView_title;
    private TwitterAdapter titleAdapter;
    private int theme = R.style.AppTheme;
    private String key;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

    public WeiBo_informationActivity() throws IOException {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        try {
            initViews();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText( WeiBo_informationActivity.this,"访问太过频繁，请30秒后再试",Toast.LENGTH_LONG ).show();
        }

    }

    private void initViews() throws IOException {
        key = getIntent().getStringExtra("key");
        titleList = get(key);
        listView_title = findViewById(R.id.listView_news);
        titleAdapter = new TwitterAdapter(titleList, this);
        listView_title.setAdapter(titleAdapter);
//        listView_title.setOnItemClickListener(this);
    }




//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        Intent intent = new Intent();
//
//        intent.putExtra("content", titleList.get(position).getContent());
//        intent.putExtra("likeCount", titleList.get(position).getLikeCount());
//        intent.putExtra("commentCount", titleList.get(position).getCommentCount());
//        intent.putExtra("shareCount", titleList.get(position).getShareCount());
//        intent.putExtra("pDate", titleList.get(position).getpDate());
//        startActivity(intent);
//    }
}

