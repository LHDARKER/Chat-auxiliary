package com.g11;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.g11.Adapter.AnalyseAdapter;
import com.g11.Bean.Analyse_info;
import com.g11.Bean.twit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

import static  com.g11.Utils.twitter_API.get;
import static  com.g11.Utils.HttpUtils1.get2;


public class Analyse_Activity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    private List<String> newsList = new ArrayList<>(  );
    private List<twit> twits= new ArrayList<>();
    private List<Analyse_info> ins=new ArrayList<Analyse_info> ();
    private ListView listView_news;
    private AnalyseAdapter AnalyseAdapter;
    private String key;
    private String Key="1";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        key = getIntent().getStringExtra("key");

        try {
            twits = get(key);
            System.out.println(twits.size());
            for(int i=0;i<10;i++){
                //System.out.println(twits.get(i).getContent());
                Key=Key+twits.get(i).getContent();

            }

            newsList=get2(Key);


        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText( Analyse_Activity.this,"访问太过频繁，请30秒后再试",Toast.LENGTH_LONG ).show();
        }





        initViews();

    }

    private void initViews() {
        listView_news = findViewById(R.id.listView_news);
        AnalyseAdapter = new AnalyseAdapter(newsList, this);
        listView_news.setAdapter(AnalyseAdapter);

    }


    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        ClipboardManager myClipboard;
//        myClipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
//        ClipData myClip;
//        myClip = ClipData.newPlainText("text", newsList.get(position));
//        myClipboard.setPrimaryClip(myClip);
//        Toast.makeText( Analyse_Activity.this,"已复制词条",Toast.LENGTH_LONG ).show();

        Intent intent = new Intent(Analyse_Activity.this,ResultActivity.class);

        System.out.println(newsList.get(position));

        intent.putExtra("key", newsList.get(position));

        startActivity(intent);
    }
}






