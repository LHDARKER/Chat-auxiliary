package com.g11;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import com.g11.Bean.User;

public class LoginActivity extends AppCompatActivity  {


    private EditText et_userid,et_pwd;

    /**登录按钮*/
    private Button btn_login;

    private TextView tv_forget_pwd,tv_register;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Bmob.initialize(this,"bdde8005ad7937e951f147d522348b75");

        initView();
    }

    private void initView(){
        setTitle(getString(R.string.btn_login));


        et_userid = (EditText)this.findViewById(R.id.et_userid);
        et_pwd = (EditText)this.findViewById(R.id.et_pwd);

    //登录

        btn_login = (Button)this.findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                doLogin();

            }
        });

    //忘记密码

//        tv_forget_pwd = (TextView)this.findViewById(R.id.tv_forget_pwd);
//        tv_forget_pwd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                startActivity(new Intent(LoginActivity.this, ForgetPwdActivity.class));
//
//            }
//        });

    //注册

        tv_register = (TextView)this.findViewById(R.id.tv_register);
        tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(LoginActivity.this, RegisteActivity.class));

            }
        });
    }

    private void toast(String msg){
        Toast.makeText( LoginActivity.this,msg,Toast.LENGTH_LONG ).show();
    }


 //登陆   存储用户信息

    private void doLogin(){

        String userid = et_userid.getText().toString();
        String pwd = et_pwd.getText().toString();
        if(userid.equals("")||pwd.equals("")){
            toast("账号或密码不能为空");
            return;
        }

        BmobQuery<User> query = new BmobQuery<User>();

        query.addWhereEqualTo("userid", userid);
        query.addWhereEqualTo("password", pwd);
        query.findObjects(new FindListener<User>() {

            @Override
            public void done(List<User> arg0, BmobException e) {
                // TODO Auto-generated method stub
                if(e==null){
//                    toast("共有"+arg0.size()+"条数据");
                    String guserid = arg0.get(0).getUserid().toString();
                    String gpassword = arg0.get(0).getPassword().toString();
//                    toast("账号:"+guserid+";密码:"+gpassword);
                    String userid = et_userid.getText().toString();
                    String pwd = et_pwd.getText().toString();
                    if(guserid.equals(userid) && gpassword.equals(pwd))
                    {
                        User.currentLoginid = userid;
                        Intent seccess = new Intent();
                        seccess.setClass(LoginActivity.this, MainActivity.class);
                        startActivity(seccess);
                    }

                }
                else{
                    toast("帐号或密码有误");
                }

            }
        });



//        RequestParams params = new RequestParams();
//        params.put("username", et_username.getText().toString());
//        params.put("password", et_pwd.getText().toString());

//        AsyncHttpHelper.post(AsyncHttpHelper.URL_LOGIN, params, new AsyncHttpHelper.MyResponseHandler(this) {
//            @Override
//            public void success(String content) {
//
//                LoginResponse res = GsonHelper.getGson().fromJson(content, LoginResponse.class);
//
//                if(res.success){
//
//                    //登录成功，把User信息保存起来
//                    ctx.user = res.user;
//
//                    toast("登录成功");
//
//                    //设置成自动登录
//
//                    ctx.setAutoLogin(true);
//                    ctx.setUsername(res.user.username);
//                    ctx.setPassword(res.user.password);
//
//                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
//                    LoginActivity.this.finish();
//
//                }else{
//
//                    Toast.makeText(LoginActivity.this, res.reason, Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        });

    }

}
