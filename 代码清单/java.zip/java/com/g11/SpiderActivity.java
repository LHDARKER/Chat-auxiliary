package com.g11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;

public class SpiderActivity extends AppCompatActivity {
    private int theme = R.style.AppTheme;
    private ImageView viw_content;
    private ImageView viw_topic;
    private ImageView viw_search;


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spider_deep);

        viw_content = (ImageView)this.findViewById(R.id.viw_content);
        viw_search = (ImageView)this.findViewById(R.id.viw_search);
        viw_topic = (ImageView)this.findViewById(R.id.viw_topic);

        viw_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(SpiderActivity.this, Info_SearchActivity.class));

            }
        });

        viw_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(SpiderActivity.this, Weibo_searchActivity.class));

            }
        });

        viw_topic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(SpiderActivity.this, Analyse_searchActivity.class));

            }
        });



    }



//        String username="adjsfj";
//        String title="adjsfj";
//
//        JSONObject jsonObject=new JSONObject();
//        try {
//            jsonObject.put("username",username);
//
//            jsonObject.put("title",username);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return jsonObject;

}
