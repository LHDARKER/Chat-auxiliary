package com.g11.Utils;

import com.g11.Bean.Analyse_info;
import com.g11.Bean.twit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import java.io.PrintWriter;
import java.net.URLConnection;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class twitter_API {
	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		 return  sb.toString();
	}

    public static JSONObject postRequestFromUrl(String url, String body) throws IOException, JSONException {
        URL realUrl = new URL(url);
        URLConnection conn = realUrl.openConnection();
        conn.setDoOutput(true);
        conn.setDoInput(true);
        PrintWriter out = new PrintWriter(conn.getOutputStream());
        out.print(body);
        out.flush();

        InputStream instream = conn.getInputStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(instream, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);


            JSONObject json = JSONObject.fromObject(jsonText);

            return json;
		} finally {
        instream.close();
        }
    }

    public static JSONObject getRequestFromUrl(String url) throws IOException, JSONException {
        URL realUrl = new URL(url);
        URLConnection conn = realUrl.openConnection();
        InputStream instream = conn.getInputStream();
        try {
        	BufferedReader rd = new BufferedReader(new InputStreamReader(instream, Charset.forName("UTF-8")));
        	String jsonText = readAll(rd);
			JSONObject json = JSONObject.fromObject(jsonText);
//        	System.out.println(json.toString());
			return json;
		} finally {
        	instream.close();
        }
    }

	public static List<twit> get(String uid) throws IOException, JSONException {
		List<twit> twitters_all = new ArrayList<twit>();
		List<twit> twitters = new ArrayList<twit>();
		for (int k = 1; k < 3; k++) {
			String url = "http://120.76.205.241:8000/post/weibo?pageToken=" + k + "&uid="+uid+"&apikey=ZKZOSU8u70IfS65NR4TFUrKSbPQTfJJO3LgJaQRV4Z8kmLETYBt2KIIfWSZwUKSS";
			JSONObject json = getRequestFromUrl(url);

			if (json.has("data")) {

				JSONArray array = null;
				array = json.getJSONArray("data");
				for (int i = 0; i < array.size(); i++) {

					JSONObject jo = array.getJSONObject(i);
					String from = jo.getString("from");
					JSONObject jo1 = JSONObject.fromObject(from);
//					String likeCount = jo1.getString("likeCount");
//					String commentCount = jo.getString("commentCount");
//					String shareCount = jo.getString("shareCount");
//					String date = jo.getString("pDate");
//					String content = jo.getString("content");
//					System.out.println(jo.getString("content"));


					twit t = new twit(jo.getString("content"),jo1.getString("likeCount"), jo.getString("commentCount"), jo.getString("shareCount"), jo.getString("pDate"));



					twitters.add(t);

				}

			} else {
				break;
			}
			twitters_all.addAll(twitters);

		}
		System.out.println(twitters_all.get(2).getContent());
		return twitters_all;
	}


}
