package com.g11;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.webkit.WebView;
import android.widget.TextView;

public class DetailActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initViews();
    }

    private void initViews() {
        WebView web_detail=findViewById(R.id.web_detail);
        web_detail.loadUrl( getIntent().getStringExtra("url"));
    }
}
