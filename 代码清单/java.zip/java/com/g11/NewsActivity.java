package com.g11;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.g11.Adapter.NewsAdapter;
import com.g11.Bean.News;
import com.g11.Bean.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class NewsActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private List<News> newsList = new ArrayList<>();
    private ListView listView_news;
    private NewsAdapter newsAdapter;
    private int theme = R.style.AppTheme;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        Bmob.initialize(this,"bdde8005ad7937e951f147d522348b75");
        initViews();
        sendForNews();
    }

    private void initViews() {
        listView_news = findViewById(R.id.listView_news);
        newsAdapter = new NewsAdapter(newsList, this);
        listView_news.setAdapter(newsAdapter);
        listView_news.setOnItemClickListener(this);
    }

    private void sendForNews() {

        OkHttpClient mOkHttpClient = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://toutiao-ali.juheapi.com/toutiao/index")
                .header("Authorization", "APPCODE b15b057efd7748e4906a58f81a846d8f")
                .get()
                .build();
        //new call
        Call call = mOkHttpClient.newCall(request);
        //请求加入调度
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //得到服务器返回的具体内容
                String responseData = response.body().string();
                System.out.println("Response----" + responseData);
                deal(responseData);
            }

            private void deal(String jsonData) {
                try {
                    JSONObject objRes = new JSONObject(jsonData);
                    String reason = objRes.optString("reason");

                    String result = objRes.optString("result");

                    JSONObject objResult = new JSONObject(result);
                    String stat = objResult.optString("stat");
                    if (stat.equals("1")) {
                        newsList.clear();
                        JSONArray jsonArayData = objResult.optJSONArray("data");
                        for (int i = 0; i < jsonArayData.length(); i++) {
                            JSONObject jsonObject = (JSONObject) jsonArayData.get(i);
                            String uniquekey = jsonObject.optString("uniquekey");
                            String title = jsonObject.optString("title");
                            String date = jsonObject.optString("date");
                            String category = jsonObject.optString("category");
                            String author_name = jsonObject.optString("author_name");
                            String url = jsonObject.optString("url");
                            String thumbnail_pic_s = jsonObject.optString("thumbnail_pic_s");
                            final News news = new News(title, date, author_name, url, thumbnail_pic_s);
                            news.setShoucanNum( 0 );
                            BmobQuery<News> query = new BmobQuery<News>();

                            query.addWhereEqualTo("title", news.getTitle());


                            query.findObjects(new FindListener<News>() {
                                @Override
                                public void done(List<News> object, BmobException e) {
                                    if(e==null){
                                        news.setShoucanNum(object.size());
                                        //获得数据的objectId信息

                                    }else{
                                        news.setShoucanNum( 0 );
                                    }
                                }
                            });
//                            BmobQuery<News> query1 = new BmobQuery<News>();
//                            query1.addWhereEqualTo("title", news.getTitle());
//                            query1.addWhereEqualTo("userid", User.currentLoginid);
//
//
//                            query1.findObjects(new FindListener<News>() {
//                                @Override
//                                public void done(List<News> object, BmobException e) {
//                                    if(e==null){
//
//                                        //获得playerName的信息
//                                        news.setShoucanFocus( true );
//                                        //获得数据的objectId信息
//
//                                    }else{
//                                        news.setShoucanFocus( false );
//                                    }
//                                }
//                            });
                            BmobQuery<News> query1 = new BmobQuery<News>();
                            query1.addWhereEqualTo("userid", User.currentLoginid);
                            query1.addWhereEqualTo("url",news.getUrl());
                            query1.findObjects(new FindListener<News>() {
                                @Override
                                public void done(List<News> object, BmobException e) {
                                    if(e==null){
                                        news.setShoucanFocus(object.get(0).isShoucanFocus());
                                        news.setObjectId(object.get(0).getObjectId());
                                    }else{
                                        Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                                    }
                                }
                            });
                            newsList.add(news);
                        }
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            newsAdapter.notifyDataSetChanged();
                        }
                    });


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();

        intent.putExtra("title", newsList.get(position).getTitle());
        intent.putExtra("date", newsList.get(position).getDate());
        intent.putExtra("category", newsList.get(position).getCategory());
        intent.putExtra("author_name", newsList.get(position).getAuthor_name());
        intent.putExtra("url", newsList.get(position).getUrl());
        intent.putExtra("thumbnail_pic_s", newsList.get(position).getThumbnail_pic_s());
        intent.putExtra( "ShoucangNum",newsList.get( position ).getShoucanNum() );
        intent.putExtra( "ShoucanFocus",newsList.get( position ).isShoucanFocus() );
        intent.setClass(this, DetailActivity.class);
        startActivity(intent);
    }
}
