package com.g11;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;


import com.g11.Adapter.NewsAdapter;
import com.g11.Adapter.TitleAdapter;
import com.g11.Bean.News;
import com.g11.Bean.title;


import java.util.ArrayList;

import java.util.List;

import static com.g11.Utils.HttpUtil.get;


public class ResultActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    protected List<News> titleList = new ArrayList<>();
    private ListView listView_title;
    private NewsAdapter titleAdapter;
    private String key;
    private int theme = R.style.AppTheme;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);


        initViews();

    }

    private void initViews() {
        key = getIntent().getStringExtra("key");
        titleList = get(key);
        listView_title = findViewById(R.id.listView_news);
        titleAdapter = new NewsAdapter(get(key), this);
        listView_title.setAdapter(titleAdapter);
        listView_title.setOnItemClickListener(this);
    }




    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();

        intent.putExtra("title", titleList.get(position).getTitle());
        intent.putExtra("date", titleList.get(position).getDate());
        intent.putExtra("author_name", titleList.get(position).getAuthor_name());
        intent.putExtra("url", titleList.get(position).getUrl());
        intent.putExtra("img_thumbnail_pic_s", titleList.get(position).getThumbnail_pic_s());
        intent.putExtra( "ShoucangNum",titleList.get( position ).getShoucanNum() );
        intent.putExtra( "ShoucanFocus",titleList.get( position ).isShoucanFocus() );
        intent.setClass(this, DetailActivity.class);
        startActivity(intent);
    }
}
