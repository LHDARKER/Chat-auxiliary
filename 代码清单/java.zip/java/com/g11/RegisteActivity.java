package com.g11;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import com.g11.Bean.User;

/**
 * 注册界面
 */
public class RegisteActivity extends AppCompatActivity {

	private EditText et_userid,et_username,et_pwd,et_pwdagain;

	/**注册按钮*/
	private Button btn_reg;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.activity_register);
		Bmob.initialize(this,"bdde8005ad7937e951f147d522348b75");

		initView();
	}

	private void initView(){

		setTitle(getString(R.string.tv_register));

		et_userid = (EditText)this.findViewById(R.id.et_userid);
		et_username = (EditText)this.findViewById(R.id.et_username);
		et_pwd = (EditText)this. findViewById(R.id.et_pwd);
		et_pwdagain = (EditText)this. findViewById(R.id.et_pwdagain);

		btn_reg = (Button)this.findViewById(R.id.reg_ok);
		btn_reg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				doRegiste();
			}
		});
	}

	private void toast(String msg){
		Toast.makeText( RegisteActivity.this,msg,Toast.LENGTH_LONG ).show();
	}

	private void doRegiste(){
		User person=new User();
		String userid = et_userid.getText().toString();
		String username = et_username.getText().toString();
		String pwd = et_pwd.getText().toString();
		String pwdagain = et_pwdagain.getText().toString();

		person.setUserid( userid );
		person.setUsername( username );
		if(userid.equals("")||pwd.equals("")){
			toast("账号或密码不能为空");
			return;
		}else if(userid.length()<5 && userid.length()>10){
			toast("用户账号需在5-10位之间");
		}else if (!userid.matches("[0-9A-Za-z_]*")){
			toast("用户账号需由字母、数字和下划线组成");
		}else if (!((userid.charAt(0)>='A'&& userid.charAt(0)<='Z') || (userid.charAt(0)>='a'&& userid.charAt(0)<='z'))){
			toast("用户账号第一位必须为字母");
		}
		else if(!pwd.equals(pwdagain)){
			toast("两次密码不同");
		}else if(pwd.length()>16||pwd.length()<8){
			toast("密码需在8-16位之间");
		}else{
			person.setPassword(pwd);
			person.save( new SaveListener<String>() {
				@Override
				public void done(String s, BmobException e) {
					if(e!=null){
						toast(e.getMessage());
					}else{
						toast("注册成功：请登录账号以继续使用");
					}
				}
			} );
			startActivity(new Intent(RegisteActivity.this, LoginActivity.class));
		}



	}
}