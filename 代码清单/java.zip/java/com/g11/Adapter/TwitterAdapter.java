package com.g11.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.g11.Utils.twitter_API;
import com.g11.Bean.twit;
import com.g11.R;

import java.util.List;

public class TwitterAdapter extends BaseAdapter {
    private List<twit> list;
    private Context context;
    private LayoutInflater inflater;


    public TwitterAdapter(List<twit> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder1 viewHolder;
        if (view == null) {
            view = inflater.inflate(R.layout.item_weibo, null);
            viewHolder = new TwitterAdapter.ViewHolder1();
            viewHolder.text_content = view.findViewById(R.id.viw_content);
            viewHolder.text_likeCount = view.findViewById(R.id.viw_likeCount);
            viewHolder.text_commentCount= view.findViewById(R.id.viw_commentCount);
            viewHolder.text_shareCount= view.findViewById(R.id.viw_shareCount);
            viewHolder.text_pDate = view.findViewById(R.id.viw_pDate);
            viewHolder.comment_img=view.findViewById( R.id.viw_comment_img );
            viewHolder.like_img=view.findViewById( R.id.viw_like_img );
            viewHolder.share_img=view.findViewById( R.id.viw_share_img);


//            viewHolder.web_url = view.findViewById(R.id.web_url);

            view.setTag(viewHolder);
        } else
            viewHolder = (ViewHolder1) view.getTag();

        twit item = list.get(position);
        if(!item.getContent().equals("转发微博")){
            viewHolder.text_content.setText(item.getContent());
            viewHolder.text_likeCount.setText(item.getLikeCount());
            viewHolder.text_commentCount.setText(item.getCommentCount());
            viewHolder.text_shareCount.setText(item.getShareCount());
            viewHolder.text_pDate.setText(item.getpDate());
            viewHolder.comment_img.setImageResource(R.drawable.message);
            viewHolder.like_img.setImageResource(R.drawable.like);
            viewHolder.share_img.setImageResource(R.drawable.share);
        }
        return view;
    }

    class ViewHolder1{
        TextView text_content;
        TextView text_likeCount;
        TextView text_commentCount;
        TextView text_shareCount;
        TextView text_pDate;
        ImageView comment_img;
        ImageView like_img;
        ImageView share_img;
    }
}
