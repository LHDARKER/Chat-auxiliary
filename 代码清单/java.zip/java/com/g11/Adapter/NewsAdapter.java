package com.g11.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.g11.Bean.News;
import com.g11.Bean.User;
import com.g11.LoginActivity;
import com.g11.NewsActivity;
import com.g11.R;
import com.g11.RegisteActivity;
import com.g11.Utils.AnimationTools;

import java.util.List;

import cn.bmob.v3.BmobBatch;
import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BatchResult;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DeleteBatchListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;

public class NewsAdapter extends BaseAdapter {

    private List<News> list;
    private Context context;
    private LayoutInflater inflater;
    private List<News> nList;
    private BmobBatch batch =new BmobBatch();

    public NewsAdapter(List<News> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        final ViewHolder viewHolder;
        final News item = list.get(position);
        if (view == null) {
            view = inflater.inflate(R.layout.item_new, null);
            viewHolder = new ViewHolder();
            viewHolder.text_uniquekey = view.findViewById(R.id.text_uniquekey);
            viewHolder.text_title = view.findViewById(R.id.text_title);
            viewHolder.text_date = view.findViewById(R.id.text_date);
            viewHolder.text_category = view.findViewById(R.id.text_category);
            viewHolder.text_author_name = view.findViewById(R.id.text_author_name);
            viewHolder.shoucang_num=view.findViewById( R.id.shoucang_num);
//            viewHolder.web_url = view.findViewById(R.id.web_url);
            viewHolder.img_thumbnail_pic_s = view.findViewById(R.id.img_thumbnail_pic_s);
            viewHolder.shoucang_img=view.findViewById( R.id.shoucang_img );

            view.setTag(viewHolder);
        } else viewHolder = (ViewHolder) view.getTag();
        Glide.with(context).load(item.getThumbnail_pic_s()).into(viewHolder.img_thumbnail_pic_s);
        viewHolder.text_uniquekey.setText(item.getUniquekey());
        viewHolder.text_title.setText(item.getTitle());
        viewHolder.text_date.setText(item.getDate());
        viewHolder.text_category.setText(item.getCategory());
        viewHolder.text_author_name.setText(item.getAuthor_name());

        if (item.isShoucanFocus()) {
            viewHolder.shoucang_img.setImageResource(R.drawable.blue);

        } else {
            viewHolder.shoucang_img.setImageResource(R.drawable.black);
        }
        viewHolder.shoucang_num.setText(item.getShoucanNum()+"");






        viewHolder.shoucang_img.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {  boolean flag = item.isShoucanFocus();
        if (flag) {
            item.setShoucanNum(item.getShoucanNum() - 1);
            item.setShoucanFocus(!flag);

            BmobQuery<News> query = new BmobQuery<News>();
            query.addWhereEqualTo("userid", User.currentLoginid);
            query.addWhereEqualTo("url",item.getUrl());
            query.findObjects(new FindListener<News>() {
                @Override
                public void done(List<News> object, BmobException e) {
                    if(e==null){
//                    toast("查询成功：共"+object.size()+"条数据。");
                        for(News n : object){
//                            nList.add(n);
                            n.getObjectId();
                            n.delete(new UpdateListener() {

                                 @Override
                                public void done(BmobException e) {
                                    if(e==null){
                                        System.out.println("删除成功:");
                                     }else{
                                        System.out.println("删除失败：" + e.getMessage());
                                    }

                                }
                            });

                        }

                    }else{
                        Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                    }
                }
            });
            item.delete(new UpdateListener() {

                @Override
                public void done(BmobException e) {
                    if(e==null){
                        Log.i("bmob","成功");
                    }else{
                        Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                    }
                }
            });


            notifyDataSetChanged();

        } else {
            item.setShoucanNum(item.getShoucanNum() + 1);
            item.setShoucanFocus(!flag);
            item.setUserid(User.currentLoginid);
            item.save( new SaveListener<String>() {
                @Override
                public void done(String s, BmobException e) {

                }
            } );
            notifyDataSetChanged();
        }


        AnimationTools.scale(viewHolder.shoucang_img);
        }
    });



            return view;
    }

    class ViewHolder {
        TextView text_uniquekey;
        TextView text_title;
        TextView text_date;
        TextView text_category;
        TextView text_author_name;
        WebView web_url;
        ImageView img_thumbnail_pic_s;
        ImageView shoucang_img;
        TextView shoucang_num;
    }
}
