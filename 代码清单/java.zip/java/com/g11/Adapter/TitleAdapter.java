package com.g11.Adapter;



import android.content.Context;
import android.view.*;
import android.webkit.WebView;
import android.widget.BaseAdapter;

import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.target.Target;
import com.g11.Bean.title;
import com.g11.R;
import com.g11.Utils.AnimationTools;

import java.util.List;
/**
 * Created by caobotao on 15/12/20.
 */

public class TitleAdapter extends BaseAdapter {
    private List<title> list;
    private Context context;
    private LayoutInflater inflater;

    public TitleAdapter(List<title> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        final viewhold viewHolder;
        final title item = list.get(position);
        if (view == null) {
            view = inflater.inflate(R.layout.item_new, parent,false);
            viewHolder = new viewhold();

            viewHolder.text_title = view.findViewById(R.id.text_title);
            viewHolder.text_date = view.findViewById(R.id.text_date);
            viewHolder.text_author_name = view.findViewById(R.id.text_author_name);
            viewHolder.shoucang_num=view.findViewById( R.id.shoucang_num);
//            viewHolder.web_url = view.findViewById(R.id.web_url);
            viewHolder.img_thumbnail_pic_s = view.findViewById(R.id.img_thumbnail_pic_s);
            viewHolder.shoucang_img=view.findViewById( R.id.shoucang_img );

            view.setTag(viewHolder);
        } else viewHolder = (viewhold) view.getTag();


        viewHolder.text_title.setText(item.getTitle());
        viewHolder.text_date.setText(item.getPubDate());
        viewHolder.text_author_name.setText(item.getChannelName());
        Glide.with(context).load( item.getImageurl() ).error( R.drawable.history).into( viewHolder.img_thumbnail_pic_s );
        if (item.isShoucanFocus()) {
            viewHolder.shoucang_img.setImageResource(R.drawable.blue);

        } else {
            viewHolder.shoucang_img.setImageResource(R.drawable.black);
        }
        viewHolder.shoucang_num.setText(item.getShoucanNum()+" ");

        viewHolder.shoucang_img.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {  boolean flag = item.isShoucanFocus();
            if (flag) { item.setShoucanNum(item.getShoucanNum() - 1);

                notifyDataSetChanged();

            } else { item.setShoucanNum(item.getShoucanNum() + 1);
                notifyDataSetChanged();
            }
            // 反向存储记录，实现取消收藏功能
            item.setShoucanFocus(!flag);
            //动画
            AnimationTools.scale(viewHolder.shoucang_img);
        }
        });
        return view;
    }

    class viewhold {
        TextView text_title;
        TextView text_date;
        TextView text_author_name;
        WebView web_url;
        ImageView img_thumbnail_pic_s;
        ImageView shoucang_img;
        TextView shoucang_num;
    }
}
