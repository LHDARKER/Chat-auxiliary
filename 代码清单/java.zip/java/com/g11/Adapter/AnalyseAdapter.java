package com.g11.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.g11.Bean.Analyse_info;
import com.g11.LoginActivity;
import com.g11.R;
import com.g11.RegisteActivity;

import java.util.List;

public class AnalyseAdapter extends BaseAdapter {
    private List<String> list;
    private Context context;
    private LayoutInflater inflater;

    public AnalyseAdapter(List<String> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        final ViewHolder viewHolder;
        final String item = list.get(position);
        if (view == null) {
            view = inflater.inflate( R.layout.item_keyword_list, null);
            viewHolder = new ViewHolder();
            viewHolder.text_keyword = view.findViewById(R.id.list_text1);
            view.setTag(viewHolder);
        } else viewHolder = (ViewHolder) view.getTag();

            viewHolder.text_keyword.setText(item);




        return view;
    }

    class ViewHolder {

        TextView text_keyword;
    }
}
