package com.g11.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.g11.Bean.News;
import com.g11.NewsActivity;
import com.g11.R;
import com.g11.Utils.AnimationTools;

import java.util.List;

public class CollectionAdapter extends BaseAdapter {
    private List<News> list;
    private Context context;
    private LayoutInflater inflater;

    public CollectionAdapter(List<News> list, Context context) {
        this.list = list;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        final  ViewHolder viewHolder;
        final News item = list.get(position);
        if (view == null) {
            view = inflater.inflate(R.layout.item_new, null);
            viewHolder = new ViewHolder();

            viewHolder.text_title = view.findViewById(R.id.text_title);
            viewHolder.text_date = view.findViewById(R.id.text_date);

            viewHolder.text_author_name = view.findViewById(R.id.text_author_name);
            viewHolder.shoucang_num=view.findViewById( R.id.shoucang_num);
//            viewHolder.web_url = view.findViewById(R.id.web_url);
            viewHolder.img_thumbnail_pic_s = view.findViewById(R.id.img_thumbnail_pic_s);
            viewHolder.shoucang_img=view.findViewById( R.id.shoucang_img );

            view.setTag(viewHolder);
        } else viewHolder = (ViewHolder) view.getTag();
        Glide.with(context).load(item.getThumbnail_pic_s()).into(viewHolder.img_thumbnail_pic_s);

        viewHolder.text_title.setText(item.getTitle());
        viewHolder.text_date.setText(item.getDate());

        viewHolder.text_author_name.setText(item.getAuthor_name());
        viewHolder.shoucang_img.setImageResource(R.drawable.blue);

        viewHolder.shoucang_num.setText(item.getShoucanNum()+"");




        return view;
    }

    class ViewHolder {
        TextView text_title;
        TextView text_date;

        TextView text_author_name;
        WebView web_url;
        ImageView img_thumbnail_pic_s;
        ImageView shoucang_img;
        TextView shoucang_num;
    }
}
