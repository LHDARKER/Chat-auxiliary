package com.g11;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.g11.Adapter.CollectionAdapter;
import com.g11.Bean.News;
import com.g11.Bean.User;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class CollectionActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private List<News> newsList = new ArrayList<>();
    private ListView listView_news;
    private CollectionAdapter collectionAdapter;
    private int theme = R.style.AppTheme;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme); }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        theme = savedInstanceState.getInt("theme"); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        initViews();
        sendForNews();
}

    private void initViews() {
        listView_news = findViewById(R.id.listView_news);
        collectionAdapter = new CollectionAdapter(newsList, this);
        listView_news.setAdapter(collectionAdapter);
        listView_news.setOnItemClickListener(this);
    }

    private void sendForNews(){

        BmobQuery<News> query = new BmobQuery<News>();

        query.addWhereEqualTo("userid", User.currentLoginid);



        query.findObjects(new FindListener<News>() {
            @Override
            public void done(List<News> object, BmobException e) {
                if(e==null){
                    for (News news : object) {
                        //获得playerName的信息
                        news.getTitle();
                        //获得数据的objectId信息
                        news.getAuthor_name();
                        //获得createdAt数据创建时间（注意是：createdAt，不是createAt）
                        news.getDate();

                        news.getThumbnail_pic_s();

                        news.getUrl();

                        news.getShoucanNum();

                        news.setShoucanFocus( false );



                        newsList.add( news );

                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            collectionAdapter.notifyDataSetChanged();
                        }
                    });
                }else{
                    Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                }
            }
        });

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();

        intent.putExtra("title", newsList.get(position).getTitle());
        intent.putExtra("date", newsList.get(position).getDate());
        intent.putExtra("author_name", newsList.get(position).getAuthor_name());
        intent.putExtra("url", newsList.get(position).getUrl());
        intent.putExtra("thumbnail_pic_s", newsList.get(position).getThumbnail_pic_s());
        intent.putExtra( "ShoucangNum",newsList.get( position ).getShoucanNum() );
        intent.putExtra( "ShoucanFocus",newsList.get( position ).isShoucanFocus() );
        intent.setClass(this, DetailActivity.class);
        startActivity(intent);
    }
}