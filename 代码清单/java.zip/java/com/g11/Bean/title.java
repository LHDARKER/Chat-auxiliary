package com.g11.Bean;

public class title {
    private String userid;
    private String title;
    private String pubDate;
    private String channelName;
    private String imageurl;
    private String link;
    private boolean ShoucangFocus;
    private int ShoucangNum;
    public title(String title,String pubDate,String channelName,String imageurl,String link,boolean ShoucangFoucs,int ShoucangNum){
        this.title = title;
        this.pubDate = pubDate;
        this.channelName = channelName;
        this.imageurl = imageurl;
        this.link = link;
        this.ShoucangFocus=ShoucangFoucs;
        this.ShoucangNum=ShoucangNum;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getPubDate() {
        return pubDate;
    }
    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getImageurl() {
        return imageurl;
    }
    public void setImageurls(String imageurls) {
        this.imageurl = imageurls;
    }


    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public boolean isShoucanFocus() {
        return ShoucangFocus;
    }

    public void setShoucanFocus(boolean shoucanFocus) {
        this.ShoucangFocus = shoucanFocus;
    }

    public int getShoucanNum() {
        return ShoucangNum;
    }

    public void setShoucanNum(int shoucanNum) {
        this.ShoucangNum = shoucanNum;
    }

}
