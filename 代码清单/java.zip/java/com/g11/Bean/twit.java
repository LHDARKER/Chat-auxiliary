package com.g11.Bean;


public class twit{
	private String content;
	private String likeCount;
	private String commentCount;
	private String shareCount;
	private String pDate;
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(String likeCount) {
		this.likeCount = likeCount;
	}
	public String getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(String commentCount) {
		this.commentCount = commentCount;
	}
	public String getShareCount() {
		return shareCount;
	}
	public void setShareCount(String shareCount) {
		this.shareCount = shareCount;
	}
	public String getpDate() {
		return pDate;
	}
	public void setpDate(String pDate) {
		this.pDate = pDate;
	}
	public twit(String content,String likeCount, String commentCount, String shareCount, String pDate) {
		super();
		this.content = content;
		this.likeCount = likeCount;
		this.commentCount = commentCount;
		this.shareCount = shareCount;
		this.pDate = pDate;
	}
	
	
}
