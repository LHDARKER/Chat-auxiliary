package com.g11.Bean;

public class Personal_info {
    private String avatarUrl;
    private String biography;
    private String location;
    private String userName;
    private String birthday;
    private String educations;
    private String idType;
    private String gender;
    private String works;
    private String registerDate;
    public String getAvatarUrl() {
        return avatarUrl;
    }
    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
    public String getBiography() {
        return biography;
    }
    public void setBiography(String biography) {
        this.biography = biography;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getBirthday() {
        return birthday;
    }
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    public String getEducations() {
        return educations;
    }
    public void setEducations(String educations) {
        this.educations = educations;
    }
    public String getIdType() {
        return idType;
    }
    public void setIdType(String idType) {
        this.idType = idType;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getWorks() {
        return works;
    }
    public void setWorks(String works) {
        this.works = works;
    }
    public String getRegisterDate() {
        return registerDate;
    }
    public void setRegisterDate(String registerDate) {
        this.registerDate = registerDate;
    }
    public Personal_info(String avatarUrl, String biography, String location, String userName, String birthday,
                 String educations, String idType, String gender, String works, String registerDate) {
        super();
        this.avatarUrl = avatarUrl;
        this.biography = biography;
        this.location = location;
        this.userName = userName;
        this.birthday = birthday;
        this.educations = educations;
        this.idType = idType;
        this.gender = gender;
        this.works = works;
        this.registerDate = registerDate;
    }


}
