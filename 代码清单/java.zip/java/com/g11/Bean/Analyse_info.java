package com.g11.Bean;

import cn.bmob.v3.BmobObject;

public class Analyse_info extends BmobObject{
    private String content;

    public Analyse_info(String text) {
        this.content=content;
    }

    public  String getContent() {
        return content;
    }

    public void setContent(String text) {
        this.content = content;
    }
}
