package com.g11.Bean;

import cn.bmob.v3.BmobObject;

public class News extends BmobObject{
    private String userid;
    private String uniquekey;
    private String title;
    private String date;
    private String category;
    private String author_name;
    private String url;
    private String thumbnail_pic_s;
    private boolean ShoucangFocus;
    private int ShoucangNum;


    public News(){}
    public News(String title, String date, String author_name, String url, String thumbnail_pic_s) {

        this.title = title;
        this.date = date;
        this.author_name = author_name;
        this.url = url;
        this.thumbnail_pic_s = thumbnail_pic_s;
    }

    public String getUniquekey() {
        return uniquekey;
    }

    public void setUniquekey(String uniquekey) {
        this.uniquekey = uniquekey;
    }
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAuthor_name() {
        return author_name;
    }

    public void setAuthor_name(String author_name) {
        this.author_name = author_name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getThumbnail_pic_s() {
        return thumbnail_pic_s;
    }

    public void setThumbnail_pic_s(String thumbnail_pic_s) {
        this.thumbnail_pic_s = thumbnail_pic_s;
    }
    public boolean isShoucanFocus() {
        return ShoucangFocus;
    }

    public void setShoucanFocus(boolean shoucanFocus) {
        this.ShoucangFocus = shoucanFocus;
    }

    public int getShoucanNum() {
        return ShoucangNum;
    }

    public void setShoucanNum(int shoucanNum) {
        this.ShoucangNum = shoucanNum;
    }


}
